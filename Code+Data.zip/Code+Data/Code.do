/// Supplementary Table 1 Descriptive statistics ///
use Data, clear
xtset code year
logout, dec(4) save(miaoshu) word replace: tabstat y Policy REA REF VSL HSA STI STO DIS DES GEG SPC EII EGR RPA TSP URI DOO TCD, stat(mean sd min max) col(stat) f(%10.4f)

/// Table 2- (1) ///
use Data, clear
global Y y
global X i.year i.code
global D P1 
set seed 42 
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 2- (2) ///
use Data, clear
xtset code year
global Y y 
global X i.year i.code
global D P2 
set seed 42 
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 2- (3)///
use Data, clear
xtset code year
global Y y 
global X i.year i.code
global D P3 
set seed 42 
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 2- (4) ///
use Data, clear
xtset code year
global Y y
global X i.year i.code
global D P4 
set seed 42 
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust


/// Table 2- (5)///
use Data, clear
xtset code year
global Y y 
global X i.year i.code
global D Policy 
set seed 42 
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 2- (6)///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD i.year i.code
global D Policy 
set seed 42 
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 2- (7)///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy 
set seed 42 
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 2- (8) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 2- (9) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy 
set seed 42 
ddml init partial, kfolds(7)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust



/// Supplementary Table 2 (1) ///
use Data, clear
xtset code year
global Y y1
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 2 (2) ///
use Data, clear
xtset code year
global Y y2
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 2 (3) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D x1
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 2 (4) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D P5
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 2 (5) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D P6
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 2 (6) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D P7
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 2 (7) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D P8
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 2 (8) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(gradboost)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(gradboost)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 2 (9) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 2 (10) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(linsvm)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(linsvm)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 3 (1) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy
global Z iv1
set seed 42 
ddml init iv, kfolds(5)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Z|X]: pystacked $Z $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 3 (2) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy
global Z iv2
set seed 42 
ddml init iv, kfolds(5)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Z|X]: pystacked $Z $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 3 (3) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy
global Z iv3
set seed 42 
ddml init iv, kfolds(5)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Z|X]: pystacked $Z $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 3 (4) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy
global Z iv4
set seed 42 
ddml init iv, kfolds(5)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Z|X]: pystacked $Z $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 3 (1) ///
use Data, clear
xtset code year
global Y REA
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 3 (2) ///
use Data, clear
xtset code year
global Y REF
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.code i.year
global D Policy 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 3 (3) ///
use Data, clear
xtset code year
global Y VSL
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.code i.year
global D Policy 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 3 (4) ///
use Data, clear
xtset code year
global Y HSA
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.code i.year
global D Policy 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 3 (5) ///
use Data, clear
xtset code year
global Y STI
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.code i.year
global D Policy 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 3 (6) ///
use Data, clear
xtset code year
global Y STO
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.code i.year
global D Policy 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 4 (1) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
gen inter1 = Policy*DIS
global D1 Policy
global D2 inter1
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D1 $X, type(reg) method(rf)
ddml E[D|X]: pystacked $D2 $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 4 (2) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
gen inter2 = Policy*DES
global D1 Policy
global D2 inter2
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D1 $X, type(reg) method(rf)
ddml E[D|X]: pystacked $D2 $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 4 (3) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
gen inter3 = Policy*GEG
global D1 Policy
global D2 INTER3
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D1 $X, type(reg) method(rf)
ddml E[D|X]: pystacked $D2 $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 4 (4) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
gen inter4 = Policy*SPC
global D1 Policy
global D2 inter4
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D1 $X, type(reg) method(rf)
ddml E[D|X]: pystacked $D2 $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust


/// Table 5 (1) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D EAST
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 5 (2) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D MIDDLE 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 5 (3) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D WEST
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 5 (4) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D NE
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 5 (5) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D C1
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 5 (6) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D C2
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 5 (7) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D B1
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Table 5 (8) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D B2
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 4 (1) ///
use Data, clear
xtset code year
global Y SSR
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 4 (2) ///
use Data, clear
xtset code year
global Y SSR1
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D P1
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 4 (3) ///
use Data, clear
xtset code year
global Y SSR
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D P2
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 4 (4) ///
use Data, clear
xtset code year
global Y ESR
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D Policy 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 4 (5) ///
use Data, clear
xtset code year
global Y ESR
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D P1
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 4 (6) ///
use Data, clear
xtset code year
global Y ESR1
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D P2
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 5 (1) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D T1 
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 5 (2) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D T2
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 5 (3) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D T3
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust

/// Supplementary Table 5 (4) ///
use Data, clear
xtset code year
global Y y
global X EII EGR RPA TSP URI DOO TCD EII2 EGR2 RPA2 TSP2 URI2 DOO2 TCD2 i.year i.code
global D T4
set seed 42 
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(rf)
ddml E[Y|X]: pystacked $Y $X, type(reg) method(rf)
ddml crossfit
ddml estimate, robust
